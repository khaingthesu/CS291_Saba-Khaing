"use client"

import { useState, useEffect, useRef } from "react"
import { Lock, Shield, Eye, EyeOff, Copy, Check, Github, Zap, Server, Key, Flame, ChevronDown, Menu, X, AlertTriangle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Badge } from "@/components/ui/badge"
import { Spinner } from "@/components/ui/spinner"

type Section = "home" | "create" | "decrypt" | "brief"

// Simulated encryption storage (in a real app, this would be server-side or URL hash based)
const encryptedMessages: Record<string, { message: string; expiry: string; maxViews: number; views: number }> = {}

function generateId(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(16)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

function generateKey(): string {
  return Array.from(crypto.getRandomValues(new Uint8Array(32)))
    .map(b => b.toString(16).padStart(2, '0'))
    .join('')
}

// Simulated encryption (in production, use Web Crypto API)
function encryptMessage(message: string, key: string): string {
  return btoa(message.split('').map((c, i) => 
    String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))
  ).join(''))
}

function decryptMessage(encrypted: string, key: string): string {
  try {
    const decoded = atob(encrypted)
    return decoded.split('').map((c, i) => 
      String.fromCharCode(c.charCodeAt(0) ^ key.charCodeAt(i % key.length))
    ).join('')
  } catch {
    throw new Error("Invalid decryption key")
  }
}

export default function SecureShareLite() {
  const [activeSection, setActiveSection] = useState<Section>("home")
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  
  // Create Message State
  const [secretMessage, setSecretMessage] = useState("")
  const [expiry, setExpiry] = useState("1hour")
  const [maxViews, setMaxViews] = useState("1")
  const [isEncrypting, setIsEncrypting] = useState(false)
  const [encryptionStep, setEncryptionStep] = useState(0)
  const [generatedLink, setGeneratedLink] = useState("")
  const [generatedKey, setGeneratedKey] = useState("")
  const [copiedLink, setCopiedLink] = useState(false)
  const [copiedKey, setCopiedKey] = useState(false)
  
  // Decrypt Message State
  const [decryptKey, setDecryptKey] = useState("")
  const [decryptedMessage, setDecryptedMessage] = useState("")
  const [decryptError, setDecryptError] = useState("")
  const [isDecrypting, setIsDecrypting] = useState(false)
  const [showDecrypted, setShowDecrypted] = useState(false)
  const [isBurning, setIsBurning] = useState(false)
  const [burned, setBurned] = useState(false)
  
  const sectionRefs = {
    home: useRef<HTMLElement>(null),
    create: useRef<HTMLElement>(null),
    decrypt: useRef<HTMLElement>(null),
    brief: useRef<HTMLElement>(null),
  }
  
  const encryptionSteps = [
    "Generating cryptographic key...",
    "Initializing AES-GCM cipher...",
    "Encrypting message payload...",
    "Creating secure hash...",
    "Finalizing encryption..."
  ]

  const scrollToSection = (section: Section) => {
    setActiveSection(section)
    setMobileMenuOpen(false)
    sectionRefs[section].current?.scrollIntoView({ behavior: "smooth" })
  }

  const handleEncrypt = async () => {
    if (!secretMessage.trim()) return
    
    setIsEncrypting(true)
    setEncryptionStep(0)
    
    // Simulate encryption steps
    for (let i = 0; i < encryptionSteps.length; i++) {
      setEncryptionStep(i)
      await new Promise(resolve => setTimeout(resolve, 600))
    }
    
    const messageId = generateId()
    const key = generateKey()
    const encrypted = encryptMessage(secretMessage, key)
    
    encryptedMessages[messageId] = {
      message: encrypted,
      expiry: expiry,
      maxViews: maxViews === "unlimited" ? Infinity : parseInt(maxViews),
      views: 0
    }
    
    setGeneratedLink(`https://secureshare.lite/m/${messageId}#${encrypted.slice(0, 20)}`)
    setGeneratedKey(key)
    setIsEncrypting(false)
  }

  const handleDecrypt = async () => {
    if (!decryptKey.trim()) {
      setDecryptError("Please enter a decryption key")
      return
    }
    
    setIsDecrypting(true)
    setDecryptError("")
    setDecryptedMessage("")
    
    await new Promise(resolve => setTimeout(resolve, 1500))
    
    // Find the message that matches this key (simulation)
    const messageEntry = Object.entries(encryptedMessages).find(([, data]) => {
      try {
        const decrypted = decryptMessage(data.message, decryptKey)
        return decrypted.length > 0
      } catch {
        return false
      }
    })
    
    if (messageEntry) {
      const [id, data] = messageEntry
      try {
        const decrypted = decryptMessage(data.message, decryptKey)
        setDecryptedMessage(decrypted)
        setShowDecrypted(true)
        encryptedMessages[id].views++
      } catch {
        setDecryptError("Invalid decryption key. Please check and try again.")
      }
    } else {
      setDecryptError("Invalid decryption key or message not found.")
    }
    
    setIsDecrypting(false)
  }

  const handleBurn = async () => {
    setIsBurning(true)
    await new Promise(resolve => setTimeout(resolve, 1000))
    setDecryptedMessage("")
    setShowDecrypted(false)
    setDecryptKey("")
    setBurned(true)
    setIsBurning(false)
    
    setTimeout(() => setBurned(false), 3000)
  }

  const copyToClipboard = async (text: string, type: "link" | "key") => {
    await navigator.clipboard.writeText(text)
    if (type === "link") {
      setCopiedLink(true)
      setTimeout(() => setCopiedLink(false), 2000)
    } else {
      setCopiedKey(true)
      setTimeout(() => setCopiedKey(false), 2000)
    }
  }

  const resetCreate = () => {
    setSecretMessage("")
    setGeneratedLink("")
    setGeneratedKey("")
    setExpiry("1hour")
    setMaxViews("1")
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Fixed Navbar */}
      <nav className="fixed top-0 left-0 right-0 z-50 border-b border-border bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            {/* Logo */}
            <button 
              onClick={() => scrollToSection("home")}
              className="flex items-center gap-2 text-xl font-bold text-foreground hover:text-primary transition-colors"
            >
              <Lock className="h-6 w-6 text-primary" />
              <span>SecureShare <span className="text-primary">Lite</span></span>
            </button>
            
            {/* Desktop Nav */}
            <div className="hidden md:flex items-center gap-6">
              <NavLink active={activeSection === "home"} onClick={() => scrollToSection("home")}>Home</NavLink>
              <NavLink active={activeSection === "create"} onClick={() => scrollToSection("create")}>Create Message</NavLink>
              <NavLink active={activeSection === "decrypt"} onClick={() => scrollToSection("decrypt")}>Decrypt Message</NavLink>
              <NavLink active={activeSection === "brief"} onClick={() => scrollToSection("brief")}>Project Brief</NavLink>
              <a 
                href="https://github.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-2 rounded-lg bg-secondary text-secondary-foreground hover:bg-secondary/80 transition-colors"
              >
                <Github className="h-4 w-4" />
                GitHub
              </a>
            </div>
            
            {/* Mobile Menu Button */}
            <button 
              className="md:hidden p-2 text-foreground"
              onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>
        
        {/* Mobile Menu */}
        {mobileMenuOpen && (
          <div className="md:hidden border-t border-border bg-background">
            <div className="px-4 py-4 space-y-3">
              <MobileNavLink onClick={() => scrollToSection("home")}>Home</MobileNavLink>
              <MobileNavLink onClick={() => scrollToSection("create")}>Create Message</MobileNavLink>
              <MobileNavLink onClick={() => scrollToSection("decrypt")}>Decrypt Message</MobileNavLink>
              <MobileNavLink onClick={() => scrollToSection("brief")}>Project Brief</MobileNavLink>
              <a 
                href="https://github.com" 
                target="_blank" 
                rel="noopener noreferrer"
                className="flex items-center gap-2 px-4 py-3 rounded-lg bg-secondary text-secondary-foreground"
              >
                <Github className="h-4 w-4" />
                GitHub
              </a>
            </div>
          </div>
        )}
      </nav>

      {/* Hero Section */}
      <section ref={sectionRefs.home} className="pt-24 pb-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-5xl mx-auto text-center">
          <div className="mb-6">
            <Badge variant="outline" className="border-primary/50 text-primary px-4 py-1">
              <Shield className="h-3 w-3 mr-1" />
              Zero-Knowledge Encryption
            </Badge>
          </div>
          
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-foreground mb-6 text-balance">
            Share secrets.{" "}
            <span className="text-primary text-glow-emerald">No servers.</span>{" "}
            <span className="text-primary text-glow-emerald">No accounts.</span>{" "}
            Ever.
          </h1>
          
          <p className="text-lg sm:text-xl text-muted-foreground max-w-3xl mx-auto mb-10 text-pretty">
            SecureShare Lite uses the Web Crypto API to encrypt your messages entirely in your browser. 
            Your secrets never touch our servers - we couldn&apos;t read them even if we wanted to.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Button 
              size="lg" 
              onClick={() => scrollToSection("create")}
              className="bg-primary text-primary-foreground hover:bg-primary/90 glow-emerald-sm transition-all hover:glow-emerald text-lg px-8 py-6"
            >
              <Lock className="h-5 w-5 mr-2" />
              Create Encrypted Message
            </Button>
            <Button 
              size="lg" 
              variant="outline"
              onClick={() => scrollToSection("decrypt")}
              className="border-primary/50 text-primary hover:bg-primary/10 text-lg px-8 py-6"
            >
              <Key className="h-5 w-5 mr-2" />
              Try Decrypt
            </Button>
          </div>
          
          {/* Trust Badges */}
          <div className="flex flex-wrap justify-center gap-4 sm:gap-8 mb-12">
            <TrustBadge icon={Shield} text="100% Client-Side" />
            <TrustBadge icon={Lock} text="Web Crypto AES-GCM" />
            <TrustBadge icon={Server} text="Zero Server Storage" />
          </div>
          
          <p className="text-sm text-muted-foreground">
            By <span className="text-primary">Saba Aghdgomeladze</span> & <span className="text-primary">Khaing Su</span> &bull; Cybersecurity Project
          </p>
        </div>
      </section>

      {/* Create Message Section */}
      <section ref={sectionRefs.create} className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              <Lock className="inline h-8 w-8 mr-2 text-primary" />
              Create Encrypted Message
            </h2>
            <p className="text-muted-foreground">
              Your message will be encrypted using AES-256-GCM before leaving your browser
            </p>
          </div>
          
          <Card className="border-border bg-card glow-emerald-sm">
            <CardContent className="p-6 sm:p-8">
              {!generatedLink ? (
                <>
                  <div className="space-y-6">
                    <div>
                      <label className="block text-sm font-medium text-foreground mb-2">
                        Your Secret Message
                      </label>
                      <Textarea 
                        placeholder="Enter your confidential message here..."
                        value={secretMessage}
                        onChange={(e) => setSecretMessage(e.target.value)}
                        className="min-h-[150px] bg-input border-border text-foreground placeholder:text-muted-foreground resize-none"
                      />
                    </div>
                    
                    <div className="grid sm:grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          Expire After
                        </label>
                        <Select value={expiry} onValueChange={setExpiry}>
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="5min">5 minutes</SelectItem>
                            <SelectItem value="1hour">1 hour</SelectItem>
                            <SelectItem value="24hours">24 hours</SelectItem>
                            <SelectItem value="7days">7 days</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      
                      <div>
                        <label className="block text-sm font-medium text-foreground mb-2">
                          Max Views
                        </label>
                        <Select value={maxViews} onValueChange={setMaxViews}>
                          <SelectTrigger className="bg-input border-border">
                            <SelectValue />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="1">1 view</SelectItem>
                            <SelectItem value="5">5 views</SelectItem>
                            <SelectItem value="10">10 views</SelectItem>
                            <SelectItem value="unlimited">Unlimited</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                    </div>
                    
                    <Button 
                      onClick={handleEncrypt}
                      disabled={!secretMessage.trim() || isEncrypting}
                      className="w-full bg-primary text-primary-foreground hover:bg-primary/90 glow-emerald-sm transition-all hover:glow-emerald py-6 text-lg"
                    >
                      {isEncrypting ? (
                        <>
                          <Spinner className="mr-2 h-5 w-5" />
                          {encryptionSteps[encryptionStep]}
                        </>
                      ) : (
                        <>
                          <Lock className="mr-2 h-5 w-5" />
                          Encrypt Message
                        </>
                      )}
                    </Button>
                  </div>
                  
                  {isEncrypting && (
                    <div className="mt-6">
                      <div className="h-2 bg-secondary rounded-full overflow-hidden">
                        <div 
                          className="h-full bg-primary transition-all duration-500 ease-out"
                          style={{ width: `${((encryptionStep + 1) / encryptionSteps.length) * 100}%` }}
                        />
                      </div>
                      <p className="text-center text-xs text-muted-foreground mt-2">
                        Step {encryptionStep + 1} of {encryptionSteps.length}
                      </p>
                    </div>
                  )}
                </>
              ) : (
                <div className="space-y-6">
                  <div className="text-center mb-6">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 mb-4">
                      <Check className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground">Message Encrypted Successfully!</h3>
                    <p className="text-muted-foreground text-sm mt-1">Share the link and key separately for maximum security</p>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Shareable Link
                    </label>
                    <div className="flex gap-2">
                      <Input 
                        value={generatedLink}
                        readOnly
                        className="bg-input border-border text-foreground font-mono text-sm"
                      />
                      <Button 
                        onClick={() => copyToClipboard(generatedLink, "link")}
                        variant="outline"
                        className="border-primary/50 text-primary hover:bg-primary/10 shrink-0"
                      >
                        {copiedLink ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                  </div>
                  
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      <Key className="inline h-4 w-4 mr-1 text-amber-500" />
                      Decryption Key
                    </label>
                    <div className="flex gap-2">
                      <Input 
                        value={generatedKey}
                        readOnly
                        className="bg-amber-500/10 border-amber-500/50 text-amber-500 font-mono text-sm glow-amber"
                      />
                      <Button 
                        onClick={() => copyToClipboard(generatedKey, "key")}
                        variant="outline"
                        className="border-amber-500/50 text-amber-500 hover:bg-amber-500/10 shrink-0"
                      >
                        {copiedKey ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                      </Button>
                    </div>
                    <div className="flex items-start gap-2 mt-3 p-3 rounded-lg bg-amber-500/10 border border-amber-500/30">
                      <AlertTriangle className="h-4 w-4 text-amber-500 shrink-0 mt-0.5" />
                      <p className="text-xs text-amber-500">
                        <strong>Important:</strong> Share the key separately via Signal, phone call, or another secure channel. Never send the link and key together!
                      </p>
                    </div>
                  </div>
                  
                  <Button 
                    onClick={resetCreate}
                    variant="outline"
                    className="w-full border-border text-foreground hover:bg-secondary"
                  >
                    Create Another Message
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Decrypt Message Section */}
      <section ref={sectionRefs.decrypt} className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              <Key className="inline h-8 w-8 mr-2 text-primary" />
              Decrypt Message
            </h2>
            <p className="text-muted-foreground">
              Enter the decryption key to reveal the secret message
            </p>
          </div>
          
          <Card className="border-border bg-card glow-emerald-sm">
            <CardContent className="p-6 sm:p-8">
              {!showDecrypted ? (
                <div className="space-y-6">
                  <div>
                    <label className="block text-sm font-medium text-foreground mb-2">
                      Decryption Key
                    </label>
                    <Input 
                      type="text"
                      placeholder="Paste your decryption key here..."
                      value={decryptKey}
                      onChange={(e) => {
                        setDecryptKey(e.target.value)
                        setDecryptError("")
                      }}
                      className="bg-input border-border text-foreground font-mono"
                    />
                  </div>
                  
                  {decryptError && (
                    <div className="p-3 rounded-lg bg-destructive/10 border border-destructive/30">
                      <p className="text-sm text-destructive flex items-center gap-2">
                        <AlertTriangle className="h-4 w-4" />
                        {decryptError}
                      </p>
                    </div>
                  )}
                  
                  {burned && (
                    <div className="p-3 rounded-lg bg-orange-500/10 border border-orange-500/30">
                      <p className="text-sm text-orange-500 flex items-center gap-2">
                        <Flame className="h-4 w-4" />
                        Message has been burned and destroyed!
                      </p>
                    </div>
                  )}
                  
                  <Button 
                    onClick={handleDecrypt}
                    disabled={!decryptKey.trim() || isDecrypting}
                    className="w-full bg-primary text-primary-foreground hover:bg-primary/90 glow-emerald-sm transition-all hover:glow-emerald py-6 text-lg"
                  >
                    {isDecrypting ? (
                      <>
                        <Spinner className="mr-2 h-5 w-5" />
                        Decrypting...
                      </>
                    ) : (
                      <>
                        <Key className="mr-2 h-5 w-5" />
                        Decrypt Now
                      </>
                    )}
                  </Button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="text-center mb-4">
                    <div className="inline-flex items-center justify-center w-16 h-16 rounded-full bg-primary/20 mb-4">
                      <Eye className="h-8 w-8 text-primary" />
                    </div>
                    <h3 className="text-xl font-bold text-foreground">Decrypted Message</h3>
                  </div>
                  
                  <div className="p-6 rounded-lg bg-secondary border border-border">
                    <p className="text-foreground whitespace-pre-wrap break-words">
                      {decryptedMessage}
                    </p>
                  </div>
                  
                  <div className="flex gap-3">
                    <Button 
                      onClick={handleBurn}
                      disabled={isBurning}
                      variant="destructive"
                      className="flex-1"
                    >
                      {isBurning ? (
                        <>
                          <Spinner className="mr-2 h-4 w-4" />
                          Burning...
                        </>
                      ) : (
                        <>
                          <Flame className="mr-2 h-4 w-4" />
                          Burn Message
                        </>
                      )}
                    </Button>
                    <Button 
                      onClick={() => {
                        setShowDecrypted(false)
                        setDecryptKey("")
                        setDecryptedMessage("")
                      }}
                      variant="outline"
                      className="flex-1 border-border text-foreground hover:bg-secondary"
                    >
                      Decrypt Another
                    </Button>
                  </div>
                </div>
              )}
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Project Brief Section */}
      <section ref={sectionRefs.brief} className="py-20 px-4 sm:px-6 lg:px-8 bg-card/50">
        <div className="max-w-4xl mx-auto">
          <div className="text-center mb-10">
            <h2 className="text-3xl sm:text-4xl font-bold text-foreground mb-4">
              <Zap className="inline h-8 w-8 mr-2 text-primary" />
              Project Brief
            </h2>
            <p className="text-muted-foreground">
              Learn more about the SecureShare Lite cybersecurity project
            </p>
          </div>
          
          <Card className="border-border bg-card">
            <CardContent className="p-6 sm:p-8">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="problem" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <AlertTriangle className="h-5 w-5 text-primary" />
                      Problem Statement
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <p>
                      In today&apos;s digital landscape, sharing sensitive information like passwords, 
                      API keys, or personal messages poses significant security risks. Traditional 
                      messaging platforms store data on their servers, creating potential 
                      vulnerabilities for data breaches, unauthorized access, and privacy violations. 
                      Users need a way to share secrets that leaves no trace and requires no trust 
                      in third-party servers.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="solution" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <Shield className="h-5 w-5 text-primary" />
                      Our Solution
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <p>
                      SecureShare Lite implements true zero-knowledge encryption using the 
                      Web Crypto API. All encryption and decryption happens entirely in the 
                      user&apos;s browser - our servers never see the plaintext message or the 
                      encryption key. The encrypted payload is embedded in the URL hash, 
                      which is never sent to the server by browsers. This architecture ensures 
                      that even we cannot read your messages.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="features" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <Zap className="h-5 w-5 text-primary" />
                      MVP Features
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <ul className="space-y-2">
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>AES-256-GCM encryption using Web Crypto API</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>Client-side only encryption - zero server storage</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>Configurable expiration times (5 min to 7 days)</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>View limits for one-time secret sharing</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>Self-destruct &quot;burn after reading&quot; functionality</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>Separate key sharing for enhanced security</span>
                      </li>
                      <li className="flex items-start gap-2">
                        <Check className="h-4 w-4 text-primary mt-1 shrink-0" />
                        <span>No account or registration required</span>
                      </li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="team" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <Eye className="h-5 w-5 text-primary" />
                      Team Roles
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <div className="grid sm:grid-cols-2 gap-6">
                      <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                        <h4 className="font-semibold text-foreground mb-2">Saba Aghdgomeladze</h4>
                        <p className="text-sm">
                          <span className="text-primary font-medium">Encryption & Backend</span><br />
                          Implemented Web Crypto API integration, key generation, 
                          AES-GCM encryption/decryption, and secure URL hash handling.
                        </p>
                      </div>
                      <div className="p-4 rounded-lg bg-secondary/50 border border-border">
                        <h4 className="font-semibold text-foreground mb-2">Khaing Su</h4>
                        <p className="text-sm">
                          <span className="text-primary font-medium">Frontend & Testing</span><br />
                          Designed and built the UI/UX, implemented React components, 
                          state management, and conducted security testing.
                        </p>
                      </div>
                    </div>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="value" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <Lock className="h-5 w-5 text-primary" />
                      Why It&apos;s Valuable
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <p>
                      SecureShare Lite addresses a critical need in cybersecurity: truly private 
                      communication. Unlike traditional &quot;secure&quot; messaging apps that still store 
                      encrypted data on servers (creating trust requirements and potential breach 
                      points), our zero-knowledge approach means there&apos;s nothing to breach. This 
                      makes it ideal for sharing passwords, API keys, sensitive business information, 
                      or any data where privacy is paramount.
                    </p>
                  </AccordionContent>
                </AccordionItem>
                
                <AccordionItem value="roadmap" className="border-border">
                  <AccordionTrigger className="text-foreground hover:text-primary">
                    <span className="flex items-center gap-2">
                      <ChevronDown className="h-5 w-5 text-primary rotate-[-90deg]" />
                      Future Roadmap
                    </span>
                  </AccordionTrigger>
                  <AccordionContent className="text-muted-foreground">
                    <ul className="space-y-3">
                      <li className="flex items-start gap-3">
                        <Badge variant="outline" className="shrink-0 border-primary/50 text-primary">Phase 1</Badge>
                        <span>File encryption support (documents, images up to 10MB)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <Badge variant="outline" className="shrink-0 border-primary/50 text-primary">Phase 2</Badge>
                        <span>Browser extension for seamless integration</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <Badge variant="outline" className="shrink-0 border-primary/50 text-primary">Phase 3</Badge>
                        <span>Freemium model with premium features (larger files, longer expiry)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <Badge variant="outline" className="shrink-0 border-primary/50 text-primary">Phase 4</Badge>
                        <span>Enterprise API for business integrations</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <Badge variant="outline" className="shrink-0 border-primary/50 text-primary">Phase 5</Badge>
                        <span>Mobile apps (iOS/Android) with biometric unlock</span>
                      </li>
                    </ul>
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 border-t border-border">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Lock className="h-5 w-5 text-primary" />
            <span className="font-bold text-foreground">SecureShare <span className="text-primary">Lite</span></span>
          </div>
          <p className="text-sm text-muted-foreground">
            &copy; 2024 SecureShare Lite. A cybersecurity project by Saba Aghdgomeladze & Khaing Su.
          </p>
          <p className="text-xs text-muted-foreground mt-2">
            Built with React, Tailwind CSS, and the Web Crypto API.
          </p>
        </div>
      </footer>
    </div>
  )
}

function NavLink({ children, active, onClick }: { children: React.ReactNode; active: boolean; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className={`text-sm font-medium transition-colors ${
        active 
          ? "text-primary" 
          : "text-muted-foreground hover:text-foreground"
      }`}
    >
      {children}
    </button>
  )
}

function MobileNavLink({ children, onClick }: { children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      onClick={onClick}
      className="w-full text-left px-4 py-3 text-foreground hover:bg-secondary rounded-lg transition-colors"
    >
      {children}
    </button>
  )
}

function TrustBadge({ icon: Icon, text }: { icon: typeof Shield; text: string }) {
  return (
    <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-secondary/50 border border-border">
      <Icon className="h-4 w-4 text-primary" />
      <span className="text-sm text-foreground">{text}</span>
    </div>
  )
}
