# AI file notes

These are the main parts that looked generator-made and were cleaned up.

## Edited because they looked AI-generated
- `app/page.tsx` (AI)
- `app/layout.tsx` (AI)
- `app/globals.css` (AI)
- `package.json` (AI cleanup)

## Removed because they were mostly generator boilerplate
- `components/ui/`
- `components/theme-provider.tsx`
- `components.json`
- `hooks/`
- `lib/`
- `styles/`
- `package-lock.json`
- `pnpm-lock.yaml`

## Left alone
- `public/`
- `tsconfig.json`
- `next.config.mjs`
- `next-env.d.ts`
- `.gitignore`

After opening the updated project, run `npm install` once so your dependencies match the cleaned `package.json`.
