// app/layout.tsx (AI)
// Cleaned up from the generated layout and removed the generator metadata.
import type { Metadata } from "next"
import "./globals.css"

export const metadata: Metadata = {
  title: "SecureShare Lite",
  description: "A class demo for sharing a short secret with a separate key.",
}

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  )
}
