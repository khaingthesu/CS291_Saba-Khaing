// app/page.tsx (AI)
// Rewritten from the generated version to feel more hand-built and less template-heavy.
"use client"

import { useMemo, useRef, useState } from "react"
import { AlertTriangle, Check, Copy, Flame, Github, KeyRound, Lock, Menu, Shield, X } from "lucide-react"

type Section = "home" | "create" | "read" | "about"
type ExpiryOption = "10 minutes" | "1 hour" | "1 day" | "7 days"
type StoredSecret = {
  cipherText: string
  expiresIn: ExpiryOption
  maxViews: number
  views: number
}

const fakeStore: Record<string, StoredSecret> = {}

function randomHex(bytes: number) {
  return Array.from(crypto.getRandomValues(new Uint8Array(bytes)))
    .map((value) => value.toString(16).padStart(2, "0"))
    .join("")
}

function scramble(text: string, key: string) {
  return btoa(
    text
      .split("")
      .map((char, index) => String.fromCharCode(char.charCodeAt(0) ^ key.charCodeAt(index % key.length)))
      .join(""),
  )
}

function unscramble(text: string, key: string) {
  const decoded = atob(text)
  return decoded
    .split("")
    .map((char, index) => String.fromCharCode(char.charCodeAt(0) ^ key.charCodeAt(index % key.length)))
    .join("")
}

export default function Page() {
  const [currentSection, setCurrentSection] = useState<Section>("home")
  const [menuOpen, setMenuOpen] = useState(false)

  const [message, setMessage] = useState("")
  const [expiry, setExpiry] = useState<ExpiryOption>("1 hour")
  const [viewLimit, setViewLimit] = useState("1")
  const [isMakingLink, setIsMakingLink] = useState(false)
  const [resultLink, setResultLink] = useState("")
  const [resultKey, setResultKey] = useState("")
  const [copied, setCopied] = useState<"link" | "key" | "">("")

  const [enteredKey, setEnteredKey] = useState("")
  const [revealedMessage, setRevealedMessage] = useState("")
  const [readError, setReadError] = useState("")
  const [isReading, setIsReading] = useState(false)
  const [messageBurned, setMessageBurned] = useState(false)

  const homeRef = useRef<HTMLElement | null>(null)
  const createRef = useRef<HTMLElement | null>(null)
  const readRef = useRef<HTMLElement | null>(null)
  const aboutRef = useRef<HTMLElement | null>(null)

  const sectionMap = useMemo(
    () => ({
      home: homeRef,
      create: createRef,
      read: readRef,
      about: aboutRef,
    }),
    [],
  )

  const openSection = (section: Section) => {
    setCurrentSection(section)
    setMenuOpen(false)
    sectionMap[section].current?.scrollIntoView({ behavior: "smooth", block: "start" })
  }

  const makeSecret = async () => {
    if (!message.trim()) return

    setIsMakingLink(true)
    await new Promise((resolve) => setTimeout(resolve, 700))

    const id = randomHex(8)
    const key = randomHex(16)
    const cipherText = scramble(message, key)

    fakeStore[id] = {
      cipherText,
      expiresIn: expiry,
      maxViews: viewLimit === "unlimited" ? Number.POSITIVE_INFINITY : Number(viewLimit),
      views: 0,
    }

    setResultLink(`https://example.com/secret/${id}`)
    setResultKey(key)
    setIsMakingLink(false)
  }

  const readSecret = async () => {
    if (!enteredKey.trim()) {
      setReadError("Enter the key first.")
      return
    }

    setIsReading(true)
    setReadError("")
    setMessageBurned(false)
    setRevealedMessage("")

    await new Promise((resolve) => setTimeout(resolve, 500))

    const foundEntry = Object.entries(fakeStore).find(([, secret]) => {
      try {
        return unscramble(secret.cipherText, enteredKey).length > 0
      } catch {
        return false
      }
    })

    if (!foundEntry) {
      setReadError("That key did not unlock anything in this demo.")
      setIsReading(false)
      return
    }

    const [id, secret] = foundEntry

    if (secret.views >= secret.maxViews) {
      setReadError("This message already reached its view limit.")
      setIsReading(false)
      return
    }

    try {
      const plainText = unscramble(secret.cipherText, enteredKey)
      fakeStore[id].views += 1
      setRevealedMessage(plainText)
    } catch {
      setReadError("The key looks wrong. Try again.")
    }

    setIsReading(false)
  }

  const burnMessage = () => {
    setRevealedMessage("")
    setEnteredKey("")
    setMessageBurned(true)
  }

  const copyValue = async (value: string, label: "link" | "key") => {
    await navigator.clipboard.writeText(value)
    setCopied(label)
    window.setTimeout(() => setCopied(""), 1500)
  }

  const startOver = () => {
    setMessage("")
    setExpiry("1 hour")
    setViewLimit("1")
    setResultLink("")
    setResultKey("")
  }

  return (
    <main className="page-shell">
      <header className="topbar">
        <button className="brand" onClick={() => openSection("home")}>
          <Lock size={18} />
          <span>SecureShare Lite</span>
        </button>

        <nav className="desktop-nav">
          <button onClick={() => openSection("home")} className={currentSection === "home" ? "nav-active" : ""}>Home</button>
          <button onClick={() => openSection("create")} className={currentSection === "create" ? "nav-active" : ""}>Create</button>
          <button onClick={() => openSection("read")} className={currentSection === "read" ? "nav-active" : ""}>Read</button>
          <button onClick={() => openSection("about")} className={currentSection === "about" ? "nav-active" : ""}>About</button>
          <a href="https://github.com" target="_blank" rel="noreferrer" className="github-link">
            <Github size={16} />
            GitHub
          </a>
        </nav>

        <button className="menu-button" onClick={() => setMenuOpen((open) => !open)} aria-label="Toggle menu">
          {menuOpen ? <X size={18} /> : <Menu size={18} />}
        </button>
      </header>

      {menuOpen && (
        <div className="mobile-nav">
          <button onClick={() => openSection("home")}>Home</button>
          <button onClick={() => openSection("create")}>Create</button>
          <button onClick={() => openSection("read")}>Read</button>
          <button onClick={() => openSection("about")}>About</button>
        </div>
      )}

      <section ref={homeRef} className="hero section">
        <p className="eyebrow">
          <Shield size={14} />
          class demo for secret sharing
        </p>
        <h1>A simple secret-sharing demo without the template look.</h1>
        <p className="hero-copy">
          This version keeps the project idea but sounds more like a real student project. It is cleaner, plainer,
          and less like it came straight out of a website generator.
        </p>
        <div className="hero-actions">
          <button className="primary-button" onClick={() => openSection("create")}>Make a message</button>
          <button className="secondary-button" onClick={() => openSection("read")}>Test a key</button>
        </div>
        <div className="team-note">Made for a cybersecurity class project by Saba Aghdgomeladze and Khaing Su.</div>
      </section>

      <section ref={createRef} className="section card-section">
        <div className="section-heading">
          <h2>Create a message</h2>
          <p>This is a demo flow that creates a link and a separate key.</p>
        </div>

        <div className="card">
          {!resultLink ? (
            <>
              <label className="field-label" htmlFor="message">Message</label>
              <textarea
                id="message"
                className="text-area"
                placeholder="Type the message you want to protect..."
                value={message}
                onChange={(event) => setMessage(event.target.value)}
              />

              <div className="field-grid">
                <div>
                  <label className="field-label" htmlFor="expiry">Expires after</label>
                  <select id="expiry" className="input" value={expiry} onChange={(event) => setExpiry(event.target.value as ExpiryOption)}>
                    <option>10 minutes</option>
                    <option>1 hour</option>
                    <option>1 day</option>
                    <option>7 days</option>
                  </select>
                </div>

                <div>
                  <label className="field-label" htmlFor="views">Max views</label>
                  <select id="views" className="input" value={viewLimit} onChange={(event) => setViewLimit(event.target.value)}>
                    <option value="1">1</option>
                    <option value="3">3</option>
                    <option value="5">5</option>
                    <option value="unlimited">Unlimited</option>
                  </select>
                </div>
              </div>

              <button className="primary-button wide-button" onClick={makeSecret} disabled={!message.trim() || isMakingLink}>
                {isMakingLink ? "Making your secret..." : "Create link"}
              </button>
            </>
          ) : (
            <div className="result-stack">
              <div className="success-box">
                <Check size={18} />
                <div>
                  <strong>Your demo link is ready.</strong>
                  <p>Send the link and key separately.</p>
                </div>
              </div>

              <div>
                <label className="field-label">Link</label>
                <div className="copy-row">
                  <input className="input" value={resultLink} readOnly />
                  <button className="icon-button" onClick={() => copyValue(resultLink, "link")}>
                    {copied === "link" ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
              </div>

              <div>
                <label className="field-label">Key</label>
                <div className="copy-row">
                  <input className="input code-input" value={resultKey} readOnly />
                  <button className="icon-button" onClick={() => copyValue(resultKey, "key")}>
                    {copied === "key" ? <Check size={16} /> : <Copy size={16} />}
                  </button>
                </div>
              </div>

              <div className="warning-box">
                <AlertTriangle size={16} />
                <span>For the project write-up: mention that this page is a demo and not production-ready encryption.</span>
              </div>

              <button className="secondary-button wide-button" onClick={startOver}>Make another</button>
            </div>
          )}
        </div>
      </section>

      <section ref={readRef} className="section card-section">
        <div className="section-heading">
          <h2>Read a message</h2>
          <p>Paste the key below and test the demo.</p>
        </div>

        <div className="card">
          {!revealedMessage ? (
            <>
              <label className="field-label" htmlFor="read-key">Key</label>
              <div className="input-with-icon">
                <KeyRound size={16} />
                <input
                  id="read-key"
                  className="input no-border"
                  placeholder="Paste the key here"
                  value={enteredKey}
                  onChange={(event) => {
                    setEnteredKey(event.target.value)
                    setReadError("")
                  }}
                />
              </div>

              {readError && <div className="error-box">{readError}</div>}
              {messageBurned && <div className="burn-box">The message was cleared from the screen.</div>}

              <button className="primary-button wide-button" onClick={readSecret} disabled={isReading || !enteredKey.trim()}>
                {isReading ? "Checking key..." : "Reveal message"}
              </button>
            </>
          ) : (
            <div className="result-stack">
              <div className="revealed-box">{revealedMessage}</div>
              <div className="button-row">
                <button className="danger-button" onClick={burnMessage}>
                  <Flame size={16} />
                  Burn from screen
                </button>
                <button
                  className="secondary-button"
                  onClick={() => {
                    setRevealedMessage("")
                    setEnteredKey("")
                  }}
                >
                  Try another
                </button>
              </div>
            </div>
          )}
        </div>
      </section>

      <section ref={aboutRef} className="section about-section">
        <div className="section-heading">
          <h2>About the project</h2>
          <p>Shorter, more believable project language.</p>
        </div>

        <div className="about-grid">
          <details className="detail-card" open>
            <summary>Problem</summary>
            <p>People sometimes need to send a password or short private note without dropping it into a normal chat.</p>
          </details>

          <details className="detail-card">
            <summary>What this demo shows</summary>
            <p>This demo shows the idea of a secret-sharing tool with a separate key and a basic burn-after-reading flow.</p>
          </details>

          <details className="detail-card">
            <summary>Important honesty note</summary>
            <p>The original generated page claimed stronger security than the code actually provided. This rewritten version avoids that.</p>
          </details>

          <details className="detail-card">
            <summary>Team split</summary>
            <p>Saba can present the security idea and logic. Khaing Su can present the interface, testing, and user flow.</p>
          </details>
        </div>
      </section>
    </main>
  )
}
